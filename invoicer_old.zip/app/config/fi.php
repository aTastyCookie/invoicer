<?php

return array(

	'defaultNumPerPage' => 15,
	'uploadPath' => __DIR__ . '/../../uploads'
	
);
@extends('layouts.empty')

@section('content')


<aside class="right-side">                

	<section class="content-header">
		<h1>{{ trans('fi.online_payments_disabled') }}</h1>
	</section>

</aside>
@stop
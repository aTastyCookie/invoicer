$(function() {

	$("#paid_at").inputmask(datepickerFormat);

});